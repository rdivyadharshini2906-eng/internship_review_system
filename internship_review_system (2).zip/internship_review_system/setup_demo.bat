@echo off
cd /d "%~dp0"
where py >nul 2>nul && (set PY=py -3) || (set PY=python)
echo This DELETES the current database and recreates 100 sample students with demo review activity.
set /p OK=Type YES to continue: 
if /i not "%OK%"=="YES" exit /b 0
if not exist .env copy .env.example .env >nul
%PY% seed.py --reset --demo-progress
pause
