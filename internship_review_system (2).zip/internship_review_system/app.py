"""Web application (standard library only). Run:  python app.py"""
import html, re, sys, threading, traceback
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, quote, urlparse
import config, db, emailer, reports, scheduler, security, workflow
from workflow import PermissionDenied, WorkflowError, STATE_LABELS

SESSIONS, THROTTLE = security.Sessions(), security.Throttle()
esc = lambda v: html.escape("" if v is None else str(v))

CSS = """body{font-family:Segoe UI,Arial,sans-serif;margin:0;background:#f4f6f9;color:#222}
header{background:#1f3a5f;color:#fff;padding:10px 20px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap}
header a{color:#fff;margin-right:14px;text-decoration:none}main{padding:20px;max-width:1250px;margin:auto}
.cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:12px}
.card{background:#fff;border-radius:8px;padding:14px;box-shadow:0 1px 3px #0002}.card b{font-size:26px;display:block}
table{border-collapse:collapse;width:100%;background:#fff}th,td{border-bottom:1px solid #e3e6ea;padding:6px 8px;text-align:left;font-size:14px;vertical-align:top}
th{background:#e9eef5}.b{padding:2px 8px;border-radius:10px;font-size:12px;color:#fff;background:#6c7a89;white-space:nowrap}
.ok{background:#2e8b57}.warn{background:#d98200}.bad{background:#c0392b}.info{background:#2f6fb5}
input,select,textarea{padding:5px;margin:2px 0;font:inherit}textarea{width:100%;box-sizing:border-box}
.flash{background:#fff3cd;padding:8px 12px;border-radius:6px;margin-bottom:12px}
.test{background:#d98200;color:#fff;text-align:center;padding:4px;font-size:13px}
.box{background:#fff;border-radius:8px;padding:14px;margin:12px 0;box-shadow:0 1px 3px #0002}pre{white-space:pre-wrap}"""


class NeedLogin(Exception):
    pass


def badge(r):
    cls = {"completed": "ok", "awaiting_review": "info", "needs_revision": "warn",
           "ended_pending": "bad", "awaiting_submission": ""}[r["state"]]
    out = '<span class="b %s">%s</span>' % (cls, esc(STATE_LABELS[r["state"]].split(" - ")[0]))
    return out + (' <span class="b bad">OVERDUE</span>' if r["overdue"] else "")


def layout(user, title, body, msg=""):
    nav = right = ""
    if user:
        links = {"hr": [("/", "Dashboard"), ("/students", "Students"), ("/students/new", "Add student"), ("/emails", "Emails"),
                        ("/report", "Final report"), ("/settings", "Settings"), ("/audit", "Audit log")],
                 "reviewer": [("/", "My review queue")], "student": [("/", "My internship")]}[user["role"]]
        nav = "".join('<a href="%s">%s</a>' % l for l in links)
        right = ('%s (%s) <form method="post" action="/logout" style="display:inline"><input type="hidden" name="csrf" '
                 'value="%s"> <button>Log out</button></form>') % (esc(user["username"]), user["role"], user["csrf"])
    test = '<div class="test">TEST MODE - emails are simulated, nothing is actually sent</div>' if config.EMAIL_MODE != "smtp" else ""
    flash = '<div class="flash">%s</div>' % esc(msg) if msg else ""
    return ('<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            '<title>%s</title><style>%s</style></head><body>%s<header><div><b>%s</b> &nbsp; %s</div><div>%s</div></header>'
            '<main>%s<h2>%s</h2>%s</main></body></html>') % (esc(title), CSS, test, esc(config.COMPANY_NAME), nav, right,
                                                             flash, esc(title), body)


def hid(user):
    return '<input type="hidden" name="csrf" value="%s">' % user["csrf"]


def table(headers, rows):
    return "<div style='overflow-x:auto'><table><tr>%s</tr>%s</table></div>" % (
        "".join("<th>%s</th>" % esc(h) for h in headers),
        "".join("<tr>%s</tr>" % "".join("<td>%s</td>" % c for c in r) for r in rows))


# ------------------------------------------------------------------ pages
def page_login(msg=""):
    return layout(None, "Sign in", '<form method="post" action="/login" class="box">Username<br><input name="username" autofocus>'
                  '<br>Password<br><input name="password" type="password"><br><br><button>Sign in</button></form>', msg)


def page_dashboard(conn, user):
    rows = reports.snapshot(conn)
    m = reports.metrics(conn, rows)
    cards = "".join('<div class="card">%s<b>%s</b></div>' % (esc(k), v) for k, v in m.items())
    near = [r for r in rows if r["state"] not in ("completed", "ended_pending") and r["total_days"] - r["day"] <= db.get_int(conn, "approaching_days")]
    t = table(["ID", "Name", "Stage", "Status", "Day"], [[esc(r["student_code"]), esc(r["name"]), r["current_stage"], badge(r),
                                                          r["day"]] for r in near]) if near else "<p>None.</p>"
    return layout(user, "HR Dashboard", '<p>Today (%s). <a href="/students?status=overdue">Overdue</a> | <a href="/students?status=needs_revision">Needs revision</a> | '
                  '<a href="/export/students.csv">Export students (CSV/Excel)</a></p><div class="cards">%s</div><h3>Students approaching the end</h3>%s'
                  % (db.today(conn), cards, t))


def page_students(conn, user, qs):
    g = lambda k: (qs.get(k) or [""])[0]
    rows = reports.filter_rows(reports.snapshot(conn), g("q"), g("stage"), g("status"), g("mentor"), g("deadline_before"))
    mentors = conn.execute("SELECT * FROM mentors ORDER BY id").fetchall()
    opt = lambda items, cur: "".join('<option value="%s"%s>%s</option>' % (esc(v), " selected" if v == cur else "", esc(l)) for v, l in items)
    form = ('<form method="get" class="box">Search <input name="q" value="%s"> Stage <select name="stage">%s</select> Status <select name="status">%s</select> '
            'Mentor <select name="mentor">%s</select> Deadline before <input type="date" name="deadline_before" value="%s"> <button>Filter</button> '
            '<a href="/students">Clear</a></form>') % (
        esc(g("q")), opt([("", "Any"), ("1", "1"), ("2", "2"), ("3", "3")], g("stage")),
        opt([("", "Any")] + [(k, v) for k, v in STATE_LABELS.items()] + [("overdue", "Overdue")], g("status")),
        opt([("", "Any")] + [(str(m["id"]), m["name"]) for m in mentors], g("mentor")), esc(g("deadline_before")))
    body = table(["ID", "Name", "Task", "Mentor", "Stage", "Status", "Deadline", "Day", "Approved"],
                 [['<a href="/student/%s">%s</a>' % (r["id"], esc(r["student_code"])), esc(r["name"]), esc(r["task_title"]), esc(r["mentor_name"]),
                   r["current_stage"], badge(r), esc(r["deadline"]), r["day"], len(r["approved"])] for r in rows])
    return layout(user, "Students (%d)" % len(rows), form + body)


def page_new_student(conn, user):
    ms = "".join('<option value="%s">%s</option>' % (m["id"], esc(m["name"])) for m in conn.execute("SELECT * FROM mentors"))
    return layout(user, "Add student", '<form method="post" action="/students/new" class="box">%s Student ID <input name="code"><br>Name <input name="name"><br>'
                  'Email <input name="email"><br>Task <input name="task" size="50"><br>Mentor <select name="mentor_id">%s</select><br>Start date '
                  '<input type="date" name="start" value="%s"><br>Initial password (min 8) <input name="password" type="password"><br><br>'
                  '<button>Add student</button></form>' % (hid(user), ms, db.today(conn)))


def can_view(user, s):
    return (user["role"] == "hr" or (user["role"] == "reviewer" and user["mentor_id"] == s["mentor_id"]) or
            (user["role"] == "student" and user["student_id"] == s["id"]))


def page_student(conn, user, sid, msg=""):
    s = conn.execute("SELECT * FROM students WHERE id=?", (sid,)).fetchone()
    if not s or not can_view(user, s):
        raise PermissionDenied("Not allowed")
    r = [x for x in reports.snapshot(conn) if x["id"] == sid][0]
    atts = conn.execute("SELECT a.*, u.username rev FROM attempts a LEFT JOIN users u ON u.id=a.reviewer_user_id "
                        "WHERE a.student_id=? ORDER BY a.stage, a.attempt_no", (sid,)).fetchall()
    arows = [[emailer.STAGE_NAMES[a["stage"]], a["attempt_no"], esc(a["submitted_at"]), esc(a["submission_note"]),
              '<span class="b %s">%s</span>' % ({"approved": "ok", "needs_revision": "warn", "submitted": "info"}[a["state"]], a["state"]),
              esc(a["rev"] or ""), esc(a["decided_at"] or ""),
              "<pre>%s</pre>" % esc("\n".join(x for x in (
                  ("Feedback: " + a["feedback"]) if a["feedback"] else "", ("Strengths: " + a["strengths"]) if a["strengths"] else "",
                  ("Corrections: " + a["corrections"]) if a["corrections"] else "",
                  ("Resubmit by: " + a["resubmit_deadline"]) if a["resubmit_deadline"] else "") if x))] for a in atts]
    stages = " ".join('<span class="b %s">Review %d: %s</span>' % (
        "ok" if n in r["approved"] else ("info" if n == r["current_stage"] and not r["state"] == "completed" else ""), n,
        "approved" if n in r["approved"] else ("current" if n == r["current_stage"] else "locked")) for n in (1, 2, 3))
    info = ('<div class="box"><b>%s</b> (%s) - %s<br>Task: %s<br>Mentor: %s | Internship %s to %s | Day %d of %d<br>Stages: %s<br>Status: %s<br>'
            'Current deadline: <b>%s</b><br>Next action: <b>%s</b></div>') % (
        esc(s["name"]), esc(s["student_code"]), esc(s["email"]), esc(s["task_title"]), esc(r["mentor_name"]), s["start_date"], s["end_date"],
        r["day"], r["total_days"], stages, badge(r), esc(s["deadline"]), esc(r["next_action"]))
    extra = ""
    if user["role"] == "student" and r["state"] in ("awaiting_submission", "needs_revision"):
        extra += ('<div class="box"><h3>Submit work for %s</h3><form method="post" action="/submit/%d">%s<textarea name="note" rows="3" '
                  'placeholder="Describe your work and paste the link to your files"></textarea><button>Submit work</button></form></div>') % (
            emailer.STAGE_NAMES[s["current_stage"]], sid, hid(user))
    pend = [a for a in atts if a["state"] == "submitted"]
    if user["role"] == "reviewer" and pend:
        extra += review_form(user, pend[0], s)
    if user["role"] == "hr":
        ms = "".join('<option value="%s"%s>%s</option>' % (m["id"], " selected" if m["id"] == s["mentor_id"] else "", esc(m["name"]))
                     for m in conn.execute("SELECT * FROM mentors"))
        extra += ('<div class="box"><h3>HR actions</h3><form method="post" action="/hr/extend/%d">%s Extend <select name="kind"><option value="deadline">current deadline'
                  '</option><option value="end_date">internship end date</option></select> to <input type="date" name="new_date"> Reason <input name="reason" size="40"> '
                  '<button>Extend (audited)</button></form><hr><form method="post" action="/hr/update/%d">%s Task <input name="task" size="40" value="%s"> Mentor '
                  '<select name="mentor_id">%s</select> <button>Update</button></form></div>') % (sid, hid(user), sid, hid(user), esc(s["task_title"]), ms)
    emails = conn.execute("SELECT * FROM email_outbox WHERE student_id=? ORDER BY id DESC", (sid,)).fetchall()
    etab = table(["Created", "Template", "To", "Status", "Tries", "Last error"], [[esc(e["created_at"]), esc(e["template"]), esc(e["to_addr"]),
                 esc(e["status"]), e["attempts"], esc(e["last_error"] or "")] for e in emails])
    return layout(user, "Student profile", info + extra + "<h3>Review attempts (history is never overwritten)</h3>" + table(
        ["Review", "Attempt", "Submitted", "Student note", "Decision", "Reviewer", "Decided", "Details"], arows) + "<h3>Email delivery</h3>" + etab, msg)


def review_form(user, a, s):
    return ('<div class="box"><h3>Evaluate %s - attempt %d</h3><p>Student note: %s</p><form method="post" action="/review/%d">%s'
            'Decision <select name="decision"><option value="approved">Approve</option><option value="needs_revision">Needs revision</option></select><br>'
            'Feedback (required)<textarea name="feedback" rows="3"></textarea>Strengths / completed work<textarea name="strengths" rows="2"></textarea>'
            'Required corrections (required if revision)<textarea name="corrections" rows="3"></textarea>Resubmission deadline (revision only) '
            '<input type="date" name="resubmit_deadline"><br><button>Record decision</button></form></div>') % (
        emailer.STAGE_NAMES[a["stage"]], a["attempt_no"], esc(a["submission_note"]), a["id"], hid(user))


def page_queue(conn, user, msg=""):
    rows = [r for r in reports.snapshot(conn) if r["mentor_id"] == user["mentor_id"]]
    pend = [r for r in rows if r["state"] == "awaiting_review"]
    t1 = table(["ID", "Name", "Stage", "Status", "Deadline"], [['<a href="/student/%s">%s</a>' % (r["id"], esc(r["student_code"])), esc(r["name"]),
               r["current_stage"], badge(r), esc(r["deadline"])] for r in pend]) if pend else "<p>No reviews waiting.</p>"
    t2 = table(["ID", "Name", "Task", "Stage", "Status", "Deadline"], [['<a href="/student/%s">%s</a>' % (r["id"], esc(r["student_code"])), esc(r["name"]),
               esc(r["task_title"]), r["current_stage"], badge(r), esc(r["deadline"])] for r in rows])
    return layout(user, "My review queue", "<h3>Waiting for your evaluation (%d)</h3>%s<h3>All my students (%d)</h3>%s" % (len(pend), t1, len(rows), t2), msg)


def page_emails(conn, user, msg=""):
    rows = conn.execute("SELECT o.*, s.student_code FROM email_outbox o LEFT JOIN students s ON s.id=o.student_id ORDER BY o.id DESC LIMIT 300").fetchall()
    body = ('<form method="post" action="/hr/run" class="box">%s <button>Run scheduler + send/retry emails now</button> '
            '<a href="/export/emails.csv">Export CSV</a></form>' % hid(user))
    return layout(user, "Email outbox & delivery log", body + table(["ID", "Created", "Student", "To", "Template", "Status", "Tries", "Next retry", "Error"],
                  [[r["id"], esc(r["created_at"]), esc(r["student_code"] or ""), esc(r["to_addr"]), esc(r["template"]), esc(r["status"]), r["attempts"],
                    esc(r["next_retry_at"] or ""), esc(r["last_error"] or "")] for r in rows]), msg)


def page_report(conn, user):
    rows = reports.final_report(reports.snapshot(conn))
    cols = list(rows[0].keys()) if rows else []
    cnt = lambda v: sum(1 for r in rows if r["Final outcome"] == v)
    return layout(user, "End-of-internship report", '<p><a href="/export/final_report.csv">Export CSV/Excel</a> | Completed: <b>%d</b> | Ended with pending reviews: <b>%d</b> | In progress: <b>%d</b></p>'
                  % (cnt("Successfully Completed"), cnt("Internship ended with pending reviews"), cnt("In progress")) +
                  table(cols, [[esc(r[c]) for c in cols] for r in rows]))


def page_settings(conn, user, msg=""):
    rows = "".join('<tr><td>%s</td><td><input name="%s" value="%s" size="50"></td></tr>' % (esc(k), esc(k), esc(db.get_setting(conn, k))) for k in config.DEFAULT_SETTINGS)
    sim = ""
    if config.EMAIL_MODE != "smtp":
        sim = '<tr><td>sim_today (TEST MODE only, blank = real date)</td><td><input name="sim_today" value="%s" placeholder="YYYY-MM-DD"></td></tr>' % esc(db.get_setting(conn, "sim_today", ""))
    return layout(user, "Settings", '<form method="post" action="/settings" class="box">%s<table>%s%s</table><button>Save</button></form>'
                  '<p>New defaults apply to students enrolled afterwards; existing deadlines change only via audited extensions.</p>' % (hid(user), rows, sim), msg)


def page_audit(conn, user):
    rows = conn.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT 300").fetchall()
    return layout(user, "Audit log", table(["Time", "Actor", "Action", "Detail"], [[esc(r["ts"]), esc(r["actor"]), esc(r["action"]), esc(r["detail"])] for r in rows]))


# ---------------------------------------------------------------- handler
class Handler(BaseHTTPRequestHandler):
    server_version = "IRMS"

    def _user(self, conn):
        c = SimpleCookie(self.headers.get("Cookie", ""))
        tok = c["sid"].value if "sid" in c else None
        s = SESSIONS.get(tok) if tok else None
        if not s:
            return None
        u = conn.execute("SELECT * FROM users WHERE id=?", (s["uid"],)).fetchone()
        if not u:
            return None
        d = dict(u)
        d["csrf"], d["tok"] = s["csrf"], tok
        return d

    def _send(self, body, status=200, ctype="text/html; charset=utf-8", headers=()):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'unsafe-inline'; form-action 'self'")
        self.send_header("Cache-Control", "no-store")
        for k, v in headers:
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _redirect(self, loc, msg="", headers=()):
        if msg:
            loc += ("&" if "?" in loc else "?") + "msg=" + quote(msg)
        self._send(b"", 303, headers=[("Location", loc)] + list(headers))

    def do_GET(self):
        self._handle("GET")

    def do_POST(self):
        self._handle("POST")

    def _handle(self, method):
        conn = db.connect()
        user = None
        try:
            u = urlparse(self.path)
            qs = parse_qs(u.query)
            msg = (qs.get("msg") or [""])[0]
            form = {}
            if method == "POST":
                n = min(int(self.headers.get("Content-Length") or 0), 1_000_000)
                form = {k: v[0] for k, v in parse_qs(self.rfile.read(n).decode("utf-8", "replace"), keep_blank_values=True).items()}
            user = self._user(conn)
            if u.path == "/login":
                return self._login(conn, method, form)
            if not user:
                return self._redirect("/login")
            if method == "POST" and form.get("csrf") != user["csrf"]:
                raise PermissionDenied("Invalid form token - reload the page and try again")
            try:
                self._route(conn, user, method, u.path, qs, form, msg)
            except WorkflowError as e:
                if isinstance(e, PermissionDenied):
                    raise
                ref = self.headers.get("Referer", "/")
                self._redirect(urlparse(ref).path or "/", str(e))
        except PermissionDenied as e:
            self._send(layout(user, "Not allowed", "<p>%s</p>" % esc(e)), 403)
        except Exception:
            traceback.print_exc()
            self._send(layout(user, "Error", "<p>Something went wrong. Details were written to the server log.</p>"), 500)
        finally:
            conn.close()

    def _login(self, conn, method, form):
        if method == "GET":
            return self._send(page_login())
        key = (self.client_address[0], form.get("username", "").lower())
        if THROTTLE.blocked(key):
            return self._send(page_login("Too many failed attempts. Try again in a few minutes."), 429)
        u = conn.execute("SELECT * FROM users WHERE username=?", (form.get("username", ""),)).fetchone()
        if u and security.verify_password(form.get("password", ""), u["password_hash"], u["salt"]):
            THROTTLE.clear(key)
            tok, _ = SESSIONS.create(u["id"])
            flags = "; HttpOnly; SameSite=Lax; Path=/" + ("; Secure" if config.COOKIE_SECURE else "")
            with conn:
                db.audit(conn, u["username"], "LOGIN", "")
            return self._redirect("/", headers=[("Set-Cookie", "sid=%s%s" % (tok, flags))])
        THROTTLE.fail(key)
        self._send(page_login("Invalid username or password."), 401)

    def _route(self, conn, user, method, p, qs, form, msg):
        role = user["role"]
        need = lambda *r: (_ for _ in ()).throw(PermissionDenied("You do not have access to this page")) if role not in r else None
        if method == "POST" and p == "/logout":
            SESSIONS.destroy(user["tok"])
            return self._redirect("/login", headers=[("Set-Cookie", "sid=; Max-Age=0; Path=/")])
        if method == "GET":
            if p == "/":
                if role == "hr":
                    return self._send(page_dashboard(conn, user))
                if role == "reviewer":
                    return self._send(page_queue(conn, user, msg))
                return self._send(page_student(conn, user, user["student_id"], msg))
            m = re.fullmatch(r"/student/(\d+)", p)
            if m:
                return self._send(page_student(conn, user, int(m.group(1)), msg))
            if p == "/students":
                need("hr"); return self._send(page_students(conn, user, qs))
            if p == "/students/new":
                need("hr"); return self._send(page_new_student(conn, user))
            if p == "/emails":
                need("hr"); return self._send(page_emails(conn, user, msg))
            if p == "/report":
                need("hr"); return self._send(page_report(conn, user))
            if p == "/settings":
                need("hr"); return self._send(page_settings(conn, user, msg))
            if p == "/audit":
                need("hr"); return self._send(page_audit(conn, user))
            m = re.fullmatch(r"/export/(students|attempts|emails|final_report)\.csv", p)
            if m:
                need("hr")
                return self._send(self._export(conn, m.group(1)), ctype="text/csv; charset=utf-8",
                                  headers=[("Content-Disposition", 'attachment; filename="%s.csv"' % m.group(1))])
            return self._send(layout(user, "Not found", "<p>Page not found.</p>"), 404)
        # ---- POST
        m = re.fullmatch(r"/submit/(\d+)", p)
        if m:
            workflow.submit_work(conn, int(m.group(1)), form.get("note", ""), user)
            return self._redirect("/student/%s" % m.group(1), "Work submitted. Your mentor has been notified.")
        m = re.fullmatch(r"/review/(\d+)", p)
        if m:
            aid = int(m.group(1))
            workflow.decide(conn, aid, user, form.get("decision", ""), form.get("feedback"), form.get("strengths"),
                            form.get("corrections"), form.get("resubmit_deadline"))
            sid = conn.execute("SELECT student_id FROM attempts WHERE id=?", (aid,)).fetchone()["student_id"]
            note = "Decision saved."
            try:  # emailing is separate: a failure here never undoes the decision
                emailer.process_outbox(conn)
            except Exception:
                traceback.print_exc()
                note += " Email delivery will be retried automatically."
            return self._redirect("/student/%s" % sid, note)
        if p == "/students/new":
            need("hr")
            workflow.enroll_student(conn, form.get("code", "").strip(), form.get("name", "").strip(), form.get("email", "").strip(),
                                    form.get("task", "").strip(), int(form.get("mentor_id") or 0), form.get("start"), user, form.get("password", ""))
            return self._redirect("/students", "Student added.")
        m = re.fullmatch(r"/hr/extend/(\d+)", p)
        if m:
            workflow.hr_extend(conn, int(m.group(1)), form.get("kind"), form.get("new_date"), form.get("reason"), user)
            return self._redirect("/student/%s" % m.group(1), "Extension recorded in the audit log.")
        m = re.fullmatch(r"/hr/update/(\d+)", p)
        if m:
            workflow.update_student(conn, int(m.group(1)), form.get("task", ""), int(form.get("mentor_id")), user)
            return self._redirect("/student/%s" % m.group(1), "Student updated.")
        if p == "/hr/run":
            need("hr")
            r = scheduler.run_cycle(conn)
            return self._redirect("/emails", "Cycle complete: %s" % r)
        if p == "/settings":
            need("hr")
            with conn:
                for k in config.DEFAULT_SETTINGS:
                    v = form.get(k, "").strip()
                    if k != "completion_formalities" and not v.isdigit():
                        raise WorkflowError("Setting %s must be a whole number" % k)
                    if v != db.get_setting(conn, k):
                        db.set_setting(conn, k, v)
                        db.audit(conn, user["username"], "SETTING", "%s=%s" % (k, v))
                if config.EMAIL_MODE != "smtp" and "sim_today" in form:
                    v = form["sim_today"].strip()
                    if v:
                        workflow.parse_date(v, "simulated date")
                    db.set_setting(conn, "sim_today", v)
                    db.audit(conn, user["username"], "SETTING", "sim_today=%s" % v)
            return self._redirect("/settings", "Settings saved.")
        return self._send(layout(user, "Not found", "<p>Not found.</p>"), 404)

    def _export(self, conn, name):
        if name == "students":
            rows = reports.snapshot(conn)
            for r in rows:
                r["approved_reviews"] = ",".join(map(str, r["approved"]))
            return reports.to_csv(rows, ["student_code", "name", "email", "task_title", "mentor_name", "start_date", "end_date",
                                         "current_stage", "approved_reviews", "label", "deadline", "day", "next_action"])
        if name == "attempts":
            rows = conn.execute("SELECT a.uid, s.student_code, a.stage, a.attempt_no, a.submitted_at, a.state, a.decided_at, a.feedback, "
                                "a.strengths, a.corrections, a.resubmit_deadline FROM attempts a JOIN students s ON s.id=a.student_id ORDER BY a.id").fetchall()
            return reports.to_csv(rows, ["uid", "student_code", "stage", "attempt_no", "submitted_at", "state", "decided_at", "feedback",
                                         "strengths", "corrections", "resubmit_deadline"])
        if name == "emails":
            rows = conn.execute("SELECT id, created_at, to_addr, template, subject, status, attempts, next_retry_at, last_error, sent_at "
                                "FROM email_outbox ORDER BY id").fetchall()
            return reports.to_csv(rows, ["id", "created_at", "to_addr", "template", "subject", "status", "attempts", "next_retry_at", "last_error", "sent_at"])
        rows = reports.final_report(reports.snapshot(conn))
        return reports.to_csv(rows, list(rows[0].keys()) if rows else [])


def main():
    conn = db.connect()
    db.init_db(conn)
    n = conn.execute("SELECT COUNT(*) c FROM students").fetchone()["c"]
    conn.close()
    if not n:
        print("No students yet. Run:  python seed.py   (add --demo-progress for sample activity)")
    scheduler.start_background(config.SCHEDULER_INTERVAL, threading.Event())
    srv = ThreadingHTTPServer((config.HOST, config.PORT), Handler)
    print("Serving on http://%s:%d  (email mode: %s)  Ctrl+C to stop" % (config.HOST, config.PORT, config.EMAIL_MODE))
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")


if __name__ == "__main__":
    main()
