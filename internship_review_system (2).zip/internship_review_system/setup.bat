@echo off
cd /d "%~dp0"
where py >nul 2>nul && (set PY=py -3) || (set PY=python)
%PY% --version || (echo Python 3.9+ not found. Install from python.org or the Microsoft Store. & pause & exit /b 1)
if not exist .env copy .env.example .env >nul
%PY% seed.py
echo.
echo Setup finished. Start the system with run.bat
pause
