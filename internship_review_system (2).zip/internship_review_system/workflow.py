"""Review state machine and business rules."""
import re, sqlite3, uuid
from datetime import date, timedelta
import db, emailer
from security import hash_password

STATE_LABELS = {
    "awaiting_submission": "Waiting for student submission",
    "awaiting_review": "Submission received - waiting for reviewer evaluation",
    "needs_revision": "Needs revision",
    "completed": "Internship completed",
    "ended_pending": "Internship ended with pending reviews",
}


class WorkflowError(Exception):
    pass


class PermissionDenied(WorkflowError):
    pass


def parse_date(v, label="date"):
    try:
        return date.fromisoformat((v or "").strip())
    except ValueError:
        raise WorkflowError("Invalid %s - use YYYY-MM-DD" % label)


def stage_deadline(conn, start, end, stage, floor=None):
    d = start + timedelta(days=db.get_int(conn, "stage%d_days" % stage))
    if floor:
        d = max(d, floor)
    return min(d, end)


def create_user(conn, username, password, role, student_id=None, mentor_id=None):
    if len(password) < 8:
        raise WorkflowError("Password must be at least 8 characters")
    h, salt = hash_password(password)
    conn.execute("INSERT INTO users(username,password_hash,salt,role,student_id,mentor_id) VALUES(?,?,?,?,?,?)",
                 (username, h, salt, role, student_id, mentor_id))


def enroll_student(conn, code, name, email, task, mentor_id, start, actor, password):
    if not (code and name and task):
        raise WorkflowError("Student ID, name and task are required")
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email or ""):
        raise WorkflowError("Invalid email address")
    start = start if isinstance(start, date) else parse_date(start, "start date")
    end = start + timedelta(days=db.get_int(conn, "internship_days") - 1)
    try:
        with conn:
            cur = conn.execute(
                "INSERT INTO students(student_code,name,email,task_title,mentor_id,start_date,end_date,deadline) "
                "VALUES(?,?,?,?,?,?,?,?)",
                (code, name, email, task, mentor_id, start.isoformat(), end.isoformat(),
                 stage_deadline(conn, start, end, 1).isoformat()))
            sid = cur.lastrowid
            create_user(conn, code, password, "student", student_id=sid)
            db.audit(conn, actor["username"] if actor else "system", "ENROLL", "%s %s" % (code, name))
    except sqlite3.IntegrityError as e:
        raise WorkflowError("Could not add student (duplicate ID/email or bad mentor): %s" % e)
    return sid


def update_student(conn, sid, task_title, mentor_id, actor):
    _need(actor, "hr")
    with conn:
        conn.execute("UPDATE students SET task_title=?, mentor_id=? WHERE id=?", (task_title, mentor_id, sid))
        db.audit(conn, actor["username"], "UPDATE_STUDENT", "id=%s task=%r mentor=%s" % (sid, task_title, mentor_id))


def _need(actor, *roles):
    if not actor or actor["role"] not in roles:
        raise PermissionDenied("You do not have permission for this action")


def _student(conn, sid):
    s = conn.execute("SELECT * FROM students WHERE id=?", (sid,)).fetchone()
    if not s:
        raise WorkflowError("Student not found")
    return s


def current_attempt(conn, s):
    return conn.execute("SELECT * FROM attempts WHERE student_id=? AND stage=? ORDER BY attempt_no DESC LIMIT 1",
                        (s["id"], s["current_stage"])).fetchone()


def compute_state(s, last, t):
    """Returns (state, overdue_flag)."""
    if s["completed"]:
        return "completed", False
    if t > date.fromisoformat(s["end_date"]):
        return "ended_pending", False
    if last is not None and last["state"] == "submitted":
        return "awaiting_review", False
    overdue = date.fromisoformat(s["deadline"]) < t
    if last is not None and last["state"] == "needs_revision":
        return "needs_revision", overdue
    return "awaiting_submission", overdue


def student_state(conn, s, t=None):
    return compute_state(s, current_attempt(conn, s), t or db.today(conn))


def next_action(s, state, overdue):
    stage = emailer.STAGE_NAMES[s["current_stage"]]
    return {
        "awaiting_submission": "Student: submit work for %s by %s" % (stage, s["deadline"]),
        "awaiting_review": "Mentor: evaluate the %s submission" % stage,
        "needs_revision": "Student: resubmit corrected work for %s by %s" % (stage, s["deadline"]),
        "completed": "None - internship task successfully completed",
        "ended_pending": "HR: review outstanding items (internship has ended)",
    }[state] + (" (OVERDUE)" if overdue else "")


def submit_work(conn, student_id, note, actor):
    if not actor or actor["role"] != "student" or actor["student_id"] != student_id:
        raise PermissionDenied("Students can only submit their own work")
    s = _student(conn, student_id)
    t = db.today(conn)
    if s["completed"]:
        raise WorkflowError("Internship already completed")
    if not s["active"]:
        raise WorkflowError("Student record is inactive")
    if t > date.fromisoformat(s["end_date"]):
        raise WorkflowError("The internship has ended; submissions are closed")
    stage = s["current_stage"]
    last = current_attempt(conn, s)
    if last is not None and last["state"] == "submitted":
        raise WorkflowError("A submission is already waiting for review")
    n = (last["attempt_no"] + 1) if last is not None else 1
    uid = uuid.uuid4().hex
    try:
        with conn:
            cur = conn.execute("INSERT INTO attempts(uid,student_id,stage,attempt_no,submitted_at,submission_note) "
                               "VALUES(?,?,?,?,?,?)", (uid, student_id, stage, n, db.now_iso(), (note or "").strip()))
            a = conn.execute("SELECT * FROM attempts WHERE id=?", (cur.lastrowid,)).fetchone()
            m = conn.execute("SELECT * FROM mentors WHERE id=?", (s["mentor_id"],)).fetchone()
            emailer.queue(conn, "reviewer_pending", student_id, "attempt:%s:pending" % uid, attempt=a, to=m["email"])
            db.audit(conn, actor["username"], "SUBMIT", "student=%s stage=%s attempt=%s" % (s["student_code"], stage, n))
    except sqlite3.DatabaseError as e:
        raise WorkflowError(str(e))
    return cur.lastrowid


def decide(conn, attempt_id, actor, decision, feedback="", strengths="", corrections="", resubmit_deadline=None):
    a = conn.execute("SELECT * FROM attempts WHERE id=?", (attempt_id,)).fetchone()
    if not a:
        raise WorkflowError("Review attempt not found")
    s = _student(conn, a["student_id"])
    if not actor or actor["role"] != "reviewer" or actor["mentor_id"] != s["mentor_id"]:
        with conn:
            db.audit(conn, actor["username"] if actor else "anonymous", "DENIED_DECISION",
                     "attempt=%s decision=%s" % (attempt_id, decision))
        raise PermissionDenied("Only the assigned reviewer can record a review decision")
    if decision not in ("approved", "needs_revision"):
        raise WorkflowError("Decision must be 'approved' or 'needs_revision'")
    if a["state"] != "submitted":
        if a["state"] == decision:
            return a["id"]  # same event processed twice: no-op, no duplicate email
        raise WorkflowError("This attempt already has a decision; it cannot be changed")
    if s["completed"] or a["stage"] != s["current_stage"]:
        raise WorkflowError("This attempt is not for the student's current review stage")
    t, end = db.today(conn), date.fromisoformat(s["end_date"])
    if t > end:
        raise WorkflowError("The internship has ended; decisions are closed (HR may extend the end date with an audit reason)")
    feedback, strengths, corrections = (feedback or "").strip(), (strengths or "").strip(), (corrections or "").strip()
    if not feedback:
        raise WorkflowError("Reviewer feedback is required")
    if decision == "needs_revision":
        if not corrections:
            raise WorkflowError("Corrective actions are required for a revision decision")
        rd = parse_date(resubmit_deadline, "resubmission deadline")
        if rd <= t or rd > end:
            raise WorkflowError("Resubmission deadline must be after today and not later than the internship end date")
        resubmit_deadline = rd.isoformat()
    else:
        resubmit_deadline = None
    try:
        with conn:
            cur = conn.execute(
                "UPDATE attempts SET state=?, reviewer_user_id=?, decided_at=?, feedback=?, strengths=?, corrections=?, "
                "resubmit_deadline=? WHERE id=? AND state='submitted'",
                (decision, actor["id"], db.now_iso(), feedback, strengths, corrections, resubmit_deadline, attempt_id))
            if cur.rowcount != 1:
                raise WorkflowError("Attempt was changed by someone else; reload and retry")
            if decision == "approved":
                if a["stage"] < 3:
                    nxt = a["stage"] + 1
                    gap = timedelta(days=db.get_int(conn, "stage_gap_days"))
                    dl = stage_deadline(conn, date.fromisoformat(s["start_date"]), end, nxt, floor=t + gap)
                    conn.execute("UPDATE students SET current_stage=?, deadline=? WHERE id=?", (nxt, dl.isoformat(), s["id"]))
                else:
                    conn.execute("UPDATE students SET completed=1, completed_at=? WHERE id=?", (db.now_iso(), s["id"]))
            else:
                conn.execute("UPDATE students SET deadline=? WHERE id=?", (resubmit_deadline, s["id"]))
            emailer.queue_outcome(conn, attempt_id)
            db.audit(conn, actor["username"], "DECISION",
                     "student=%s stage=%s attempt=%s -> %s" % (s["student_code"], a["stage"], a["attempt_no"], decision))
    except sqlite3.DatabaseError as e:
        raise WorkflowError(str(e))
    return attempt_id


def hr_extend(conn, sid, kind, new_date, reason, actor):
    _need(actor, "hr")
    s = _student(conn, sid)
    nd = parse_date(new_date, "new date")
    if not (reason or "").strip():
        raise WorkflowError("A reason is required for any extension (it is written to the audit log)")
    if kind == "deadline":
        if nd > date.fromisoformat(s["end_date"]):
            raise WorkflowError("Deadline cannot be after the internship end date; extend the end date first")
        col, old = "deadline", s["deadline"]
    elif kind == "end_date":
        if nd <= date.fromisoformat(s["end_date"]):
            raise WorkflowError("New end date must be later than the current end date")
        col, old = "end_date", s["end_date"]
    else:
        raise WorkflowError("Unknown extension type")
    with conn:
        conn.execute("UPDATE students SET %s=? WHERE id=?" % col, (nd.isoformat(), sid))
        db.audit(conn, actor["username"], "EXTEND_" + col.upper(),
                 "student=%s %s -> %s reason=%s" % (s["student_code"], old, nd, reason.strip()))
