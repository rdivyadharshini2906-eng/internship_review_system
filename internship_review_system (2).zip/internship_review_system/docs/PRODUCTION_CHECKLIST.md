# Prototype vs production - checklist

This package is a **prototype**. Before real student data goes in, tick every item:

- [ ] Run behind HTTPS (Caddy/nginx/IIS reverse proxy or a PaaS); set `COOKIE_SECURE=1`; bind app to 127.0.0.1 behind the proxy.
- [ ] Replace all demo passwords; add password-reset and forced first-login change (not built).
- [ ] Add MFA for HR accounts (not built); consider SSO.
- [ ] Real SMTP/transactional provider with SPF/DKIM/DMARC; test with real mailboxes; check the provider's daily send limits (100 students x ~10 emails fits most free tiers, but verify).
- [ ] Credentials only in environment variables / secret store; `.env` never committed.
- [ ] Daily automated backups of `data/internship.db` and a tested restore.
- [ ] Sessions are in memory (lost on restart, single process). Use PostgreSQL + a proper web framework / WSGI server if more than one process or >100s of users.
- [ ] File uploads are not built: students paste links in the submission note. Add storage + virus scanning if needed.
- [ ] Privacy: retention period, consent, access log review (audit log provided).
- [ ] Load/security review by someone independent; run on a real Windows/Linux server for a pilot cohort first.
