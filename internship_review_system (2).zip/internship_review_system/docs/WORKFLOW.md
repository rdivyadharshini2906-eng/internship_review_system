# Workflow and architecture

```mermaid
flowchart TD
  S([Student submits work]) --> A[New review attempt created<br/>mentor notified]
  A --> R{Assigned mentor decides}
  R -- Approved --> AP[Attempt locked as approved<br/>outcome email queued]
  AP --> N{Was it Review 3?}
  N -- No --> U[Next review unlocked<br/>new deadline set]
  U --> S
  N -- Yes --> C([Successfully Completed<br/>final email queued])
  R -- Needs revision --> RV[Feedback, corrections, deadline saved<br/>revision email queued]
  RV --> K[Student stays at same review<br/>next review stays locked]
  K --> S
  D[[Scheduler]] -. reminders / overdue flags, never auto-reject .-> S
  E[[Day 100 reached]] -. pending reviews reported, not marked successful .-> X([Internship ended with pending reviews])
```

```mermaid
flowchart LR
  B[Browser: HR / Mentor / Student] --> W[app.py HTTP server<br/>sessions, CSRF, roles]
  W --> F[workflow.py rules]
  F --> DB[(SQLite: students, attempts,<br/>outbox, email_log, audit_log)]
  T[scheduler.py thread] --> DB
  T --> M[emailer.py outbox]
  F --> M
  M -->|simulate| FILES[sent_emails/*.txt]
  M -->|smtp| SMTP[Your mail provider]
```

Rules enforced twice (Python in `workflow.py`, SQLite triggers in `db.py`): no attempt at Review N+1 before Review N is approved;
one open attempt per review; decided attempts are immutable; attempts can never be deleted.
Email sending is a separate step from approval: decisions are saved first, emails go through an outbox with unique keys and retries.
