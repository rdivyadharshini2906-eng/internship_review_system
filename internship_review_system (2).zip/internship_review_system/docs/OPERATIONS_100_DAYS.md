# HR operating procedure (100 days)

**Before Day 1:** copy `.env.example` to `.env`; set company/HR details; keep `EMAIL_MODE=simulate` until a pilot with 2-3 of your own mailboxes works in `smtp` mode; replace demo passwords; enrol students (Add student) and confirm mentors.
**Daily (5 min):** Dashboard -> check *Overdue*, *Needs revision*, *Emails failed*. Open *Emails* and press "Run scheduler + send/retry now" if anything is failed.
**Weekly:** filter Students by mentor and stage; chase mentors with pending reviews; export CSV for records; back up `data/internship.db`.
**Exceptions:** use "Extend (audited)" on the student profile - a reason is mandatory and is written to the audit log. No silent overrides exist.
**Days 90-100:** dashboard shows students approaching the end; extend the end date only with a recorded reason.
**After Day 100:** open *Final report*; export it. Students not approved at Review 3 appear as "Internship ended with pending reviews" - never as successful.
