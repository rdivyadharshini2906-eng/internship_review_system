# Internship Review Management System (prototype)

Virtual Management Wings Private Limited - 100 students, 100 days, three sequential reviews.
Pure Python standard library: **no pip install, no pypi.org, no 403 problem.** Python 3.9+ only.

## What it does
- Three reviews in strict order. Approval unlocks the next review; "needs revision" keeps the student at the same review and the next one locked. Resubmission = a new attempt; old attempts and feedback are never overwritten.
- Roles: HR admin, reviewer/mentor, student (students cannot approve anything).
- HR dashboard (all required counters), searchable/filterable student list, student profile with attempts/emails/next action, CSV exports (open in Excel), end-of-internship report, audit log, settings.
- 10 email templates (6 review outcomes, reminder, overdue, reviewer-pending, completion), personalised from real data, with Day X of 100, mentor contact and HR signature.
- Scheduler thread: deadline reminders, overdue flags (never auto-reject), email retry with backoff, reminders stop after the end date.
- Duplicate protection: every email has a unique key; repeating the same decision is a no-op.
- **Safe test mode (default):** `EMAIL_MODE=simulate` - emails are written as text files in `sent_emails/`; nothing leaves your PC.

## Quick start on Windows + VS Code
1. Unzip, then in VS Code: File > Open Folder > the unzipped folder.
2. Install Python 3.9+ if missing (python.org or Microsoft Store). Tick "Add Python to PATH".
3. Double-click **setup_demo.bat** (type YES) - creates the database with 100 students and sample review activity.
   (Use **setup.bat** instead for a clean start where nobody has submitted yet.)
4. Double-click **run.bat** - opens http://127.0.0.1:8000
5. Sign in (demo password `Demo@12345`): `hr.admin`, `mentor1`..`mentor5`, or any student `VMW-001`..`VMW-100`.
6. Tests: **test.bat**. Preview simulated emails in the `sent_emails` folder.

Without the .bat files (VS Code terminal):
```
python seed.py --reset --demo-progress
python app.py
python -m unittest discover -v
```
If `python` is not recognised use `py -3` instead. If Python can't be installed system-wide, the "embeddable zip" from python.org works unzipped (run `python.exe app.py` from that folder path); no pip is needed.

Try it: log in as `VMW-002` (waiting for Review 2) and submit; log in as `mentor2`, open the student, approve or request revision; log in as HR and open *Emails*.

## Test mode, dates and real email
- HR > Settings has **sim_today** (test mode only) to pretend it is another date, e.g. to see overdue reminders or Day 100. Clear it to return to the real date.
- To simulate an email outage: set `EMAIL_SIMULATE_FAIL=1`, decide a review (decision is kept, email shows *failed* with a retry time), unset it, then press "Run scheduler + send/retry now" after the retry time.
- Real email: set `EMAIL_MODE=smtp` plus `SMTP_*` in `.env` (use an app password/API key). Never put passwords in source files or share `.env`. Check your provider's sending limits first; pilot with your own mailboxes.

## Files
`app.py` web UI/routes - `workflow.py` rules/state machine - `db.py` schema + triggers - `emailer.py` outbox/send/retry - `email_templates.py` the 10 templates - `scheduler.py` reminders - `reports.py` dashboard/exports - `security.py` hashing/sessions - `seed.py` 100 sample students - `tests/` scenario tests - `docs/` workflow diagrams, 100-day HR procedure, production checklist.

## What was actually verified (honest status)
Verified in the build environment (Linux, Python 3.12.3):
- 14 automated tests pass, covering scenarios A-J (pass R1, fail R1 + resubmit, pass R1/fail R2, all three pass + final email, overdue not rejected, email outage + safe retry, independent students, Day 100 with pending review, duplicate event, unauthorised approval) plus validation, audit and CSV-safety checks.
- Seeding 100 students with demo progress, and an HTTP smoke test: login/logout, role restrictions (HTTP 403), CSRF rejection, student submit, mentor revision decision, dashboard, filters, CSV export.

**Not verified:** running on Windows or the .bat files, VS Code launch configs, visual appearance in a browser, real SMTP delivery, HTTPS/deployment, large-scale load. Treat as a prototype; see `docs/PRODUCTION_CHECKLIST.md`.

## Known limitations
No file upload (students paste links), no password reset or MFA, sessions are in memory, single-process SQLite (fine for ~100 students), demo password is public.
