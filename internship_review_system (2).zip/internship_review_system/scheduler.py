"""Periodic checks: deadline reminders, overdue flags (never auto-reject), outbox delivery/retry."""
import threading, traceback
from datetime import date
import db, emailer, workflow


def run_cycle(conn, sender=None, now=None):
    t = db.today(conn)
    before = db.get_int(conn, "reminder_days_before")
    repeat = max(1, db.get_int(conn, "overdue_repeat_days"))
    queued = {"reminder": 0, "overdue": 0}
    for s in conn.execute("SELECT s.*, m.email mentor_email FROM students s JOIN mentors m ON m.id=s.mentor_id "
                          "WHERE s.active=1 AND s.completed=0"):
        if t > date.fromisoformat(s["end_date"]):
            continue  # internship over: ordinary reminders stop
        state, overdue = workflow.student_state(conn, s, t)
        if state == "awaiting_review":
            continue  # the ball is with the reviewer
        d = date.fromisoformat(s["deadline"])
        left = (d - t).days
        steps = ("Log in to the portal and use 'Submit work' for your %s." % emailer.STAGE_NAMES[s["current_stage"]])
        with conn:
            if 0 <= left <= before:
                if emailer.queue(conn, "reminder", s["id"], "remind:%s:%s:%s" % (s["id"], s["current_stage"], d),
                                 extra={"next_steps": steps}):
                    queued["reminder"] += 1
            elif left < 0:
                k = (-left - 1) // repeat
                if emailer.queue(conn, "overdue", s["id"], "overdue:%s:%s:%s:%s" % (s["id"], s["current_stage"], d, k),
                                 cc=s["mentor_email"], extra={"next_steps": steps}):
                    queued["overdue"] += 1
                    db.audit(conn, "scheduler", "OVERDUE_FLAG",
                             "student=%s stage=%s deadline=%s" % (s["student_code"], s["current_stage"], d))
    sent = emailer.process_outbox(conn, sender=sender, now=now)
    return {"queued": queued, "delivery": sent}


def start_background(interval, stop_event):
    def loop():
        while not stop_event.wait(interval):
            try:
                conn = db.connect()
                try:
                    run_cycle(conn)
                finally:
                    conn.close()
            except Exception:
                traceback.print_exc()
    th = threading.Thread(target=loop, daemon=True, name="scheduler")
    th.start()
    return th
