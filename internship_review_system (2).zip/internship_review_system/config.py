"""Configuration. Values come from environment variables or an optional .env file."""
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def _load_env():
    p = os.path.join(BASE_DIR, ".env")
    if os.path.exists(p):
        with open(p, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


_load_env()


def env(key, default=""):
    return os.environ.get(key, default)


DB_PATH = env("DB_PATH", os.path.join(BASE_DIR, "data", "internship.db"))
HOST = env("HOST", "127.0.0.1")
PORT = int(env("PORT", "8000"))
COMPANY_NAME = env("COMPANY_NAME", "Virtual Management Wings Private Limited")
HR_NAME = env("HR_NAME", "HR Team")
HR_EMAIL = env("HR_EMAIL", "hr@example.test")
PORTAL_URL = env("PORTAL_URL", "http://localhost:8000")

# simulate = nothing is ever sent (safe test mode). smtp = real sending.
EMAIL_MODE = env("EMAIL_MODE", "simulate").lower()
SIM_DIR = env("SIM_DIR", os.path.join(BASE_DIR, "sent_emails"))
SMTP_HOST = env("SMTP_HOST")
SMTP_PORT = int(env("SMTP_PORT", "587"))
SMTP_USER = env("SMTP_USER")
SMTP_PASSWORD = env("SMTP_PASSWORD")
SMTP_FROM = env("SMTP_FROM", "")
SCHEDULER_INTERVAL = int(env("SCHEDULER_INTERVAL", "60"))  # seconds
COOKIE_SECURE = env("COOKIE_SECURE", "0") == "1"  # set 1 when served over HTTPS

DEFAULT_SETTINGS = {
    "internship_days": "100",
    "stage1_days": "30",     # default First Review deadline = start + N days
    "stage2_days": "60",
    "stage3_days": "90",
    "stage_gap_days": "7",   # minimum days given for the next stage after an approval
    "reminder_days_before": "2",
    "overdue_repeat_days": "3",
    "approaching_days": "10",
    "email_max_attempts": "5",
    "completion_formalities": "HR will contact you to complete exit formalities and issue your internship completion certificate.",
}
