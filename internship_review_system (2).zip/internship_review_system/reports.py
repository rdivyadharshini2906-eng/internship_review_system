"""Dashboard metrics, student listing/filtering, final report and CSV helpers."""
import csv, io
from datetime import date
import db, workflow
from workflow import STATE_LABELS


def snapshot(conn):
    t = db.today(conn)
    last, approved, count = {}, {}, {}
    for a in conn.execute("SELECT * FROM attempts ORDER BY student_id, stage, attempt_no"):
        last[(a["student_id"], a["stage"])] = a
        count[a["student_id"]] = count.get(a["student_id"], 0) + 1
        if a["state"] == "approved":
            approved.setdefault(a["student_id"], []).append(a["stage"])
    rows = []
    for s in conn.execute("SELECT s.*, m.name mentor_name FROM students s JOIN mentors m ON m.id=s.mentor_id ORDER BY s.student_code"):
        l = last.get((s["id"], s["current_stage"]))
        state, overdue = workflow.compute_state(s, l, t)
        start, end = date.fromisoformat(s["start_date"]), date.fromisoformat(s["end_date"])
        total = (end - start).days + 1
        d = dict(s)
        d.update(state=state, overdue=overdue, label=STATE_LABELS[state] + (" [OVERDUE]" if overdue else ""),
                 approved=sorted(approved.get(s["id"], [])), attempts=count.get(s["id"], 0),
                 day=max(1, min(total, (t - start).days + 1)), total_days=total,
                 next_action=workflow.next_action(s, state, overdue))
        rows.append(d)
    return rows


def metrics(conn, rows):
    near = db.get_int(conn, "approaching_days")
    active = [r for r in rows if r["active"] and r["state"] not in ("completed", "ended_pending")]
    m = {"Total students enrolled": len(rows), "Students currently active": len(active)}
    for n, w in ((1, "First"), (2, "Second"), (3, "Third")):
        m["%s reviews pending" % w] = sum(1 for r in rows if r["current_stage"] == n and r["state"] == "awaiting_review")
        m["%s reviews approved" % w] = sum(1 for r in rows if n in r["approved"])
    m["Tasks requiring revision"] = sum(1 for r in rows if r["state"] == "needs_revision")
    m["Overdue submissions"] = sum(1 for r in rows if r["overdue"])
    m["Completed internships"] = sum(1 for r in rows if r["state"] == "completed")
    m["Approaching Day %d" % (rows[0]["total_days"] if rows else 100)] = sum(
        1 for r in active if r["total_days"] - r["day"] <= near)
    m["Ended with pending reviews"] = sum(1 for r in rows if r["state"] == "ended_pending")
    m["Emails failed / retrying"] = conn.execute(
        "SELECT COUNT(*) c FROM email_outbox WHERE status IN ('failed','failed_permanent')").fetchone()["c"]
    return m


def filter_rows(rows, q="", stage="", status="", mentor="", deadline_before=""):
    out = []
    for r in rows:
        if q and q.lower() not in (r["student_code"] + " " + r["name"]).lower():
            continue
        if stage and str(r["current_stage"]) != stage:
            continue
        if status == "overdue" and not r["overdue"]:
            continue
        if status and status != "overdue" and r["state"] != status:
            continue
        if mentor and str(r["mentor_id"]) != mentor:
            continue
        if deadline_before and r["deadline"] > deadline_before:
            continue
        out.append(r)
    return out


def final_status(r):
    return {"completed": "Successfully Completed",
            "ended_pending": "Internship ended with pending reviews"}.get(r["state"], "In progress")


def final_report(rows):
    out = []
    for r in rows:
        out.append({"Student ID": r["student_code"], "Name": r["name"], "Mentor": r["mentor_name"],
                    "Reviews approved": len(r["approved"]), "Current stage": r["current_stage"],
                    "Status": r["label"], "Final outcome": final_status(r),
                    "Unresolved revision": "Yes" if r["state"] == "needs_revision" else "No",
                    "Pending task": "" if r["state"] == "completed" else next_pending(r)})
    return out


def next_pending(r):
    return "Review %d (%s)" % (r["current_stage"], STATE_LABELS["awaiting_review" if r["state"] == "awaiting_review" else "awaiting_submission"])


def _safe(v):
    v = "" if v is None else str(v)
    return "'" + v if v[:1] in ("=", "+", "-", "@") else v  # prevent spreadsheet formula injection


def to_csv(rows, columns):
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(columns)
    for r in rows:
        w.writerow([_safe(r[c]) for c in columns])
    return ("\ufeff" + buf.getvalue()).encode("utf-8")  # BOM so Excel opens UTF-8 correctly
