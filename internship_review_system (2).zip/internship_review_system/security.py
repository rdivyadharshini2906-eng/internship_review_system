"""Password hashing, in-memory sessions and login throttling (standard library only)."""
import hashlib, hmac, secrets, threading, time

ITER = 120_000


def hash_password(pw, salt=None):
    salt = salt or secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), bytes.fromhex(salt), ITER).hex()
    return h, salt


def verify_password(pw, h, salt):
    return hmac.compare_digest(hash_password(pw, salt)[0], h)


class Sessions:
    def __init__(self, ttl=8 * 3600):
        self.ttl, self._d, self._l = ttl, {}, threading.Lock()

    def create(self, user_id):
        tok, csrf = secrets.token_urlsafe(32), secrets.token_urlsafe(16)
        with self._l:
            self._d[tok] = {"uid": user_id, "csrf": csrf, "exp": time.time() + self.ttl}
        return tok, csrf

    def get(self, tok):
        with self._l:
            s = self._d.get(tok)
            if s and s["exp"] > time.time():
                return s
            self._d.pop(tok, None)
            return None

    def destroy(self, tok):
        with self._l:
            self._d.pop(tok, None)


class Throttle:
    def __init__(self, max_fail=5, window=300):
        self.max_fail, self.window, self._d = max_fail, window, {}

    def blocked(self, key):
        t = [x for x in self._d.get(key, []) if x > time.time() - self.window]
        self._d[key] = t
        return len(t) >= self.max_fail

    def fail(self, key):
        self._d.setdefault(key, []).append(time.time())

    def clear(self, key):
        self._d.pop(key, None)
