"""The ten email templates. Placeholders are filled from real student/review data."""

INFO = """Company: {company}
Student: {name} (ID: {code})
Assigned task: {task}
Review: {review_name} (attempt {attempt_no})
Outcome: {outcome}
Internship progress: Day {day} of {total_days}
"""

FOOT = """
Questions? Contact your mentor, {mentor_name}, at {mentor_email}.
Portal: {portal_url}

Kind regards,
{hr_name}
Human Resources
{company}
{hr_email}
"""


def _approved(word, unlock):
    return ("[{company}] " + word + " Review approved - {code}",
            "Dear {name},\n\nCongratulations - your " + word + " Review has been APPROVED.\n\n" + INFO +
            "\nReviewer comments:\n{comments}\n\n{strengths_block}"
            "Next steps:\n{next_steps}\n\n" + unlock + "\nSubmission deadline for your next step: {deadline}\n" + FOOT)


def _revision(word, locked):
    return ("[{company}] " + word + " Review needs revision - {code}",
            "Dear {name},\n\nYour " + word + " Review has been evaluated and needs REVISION. "
            "This is not a final rejection - you can resubmit.\n\n" + INFO +
            "\nReviewer comments:\n{comments}\n\n{strengths_block}{corrections_block}"
            "How to resubmit:\n{next_steps}\n\nResubmission deadline: {deadline}\n" + locked + "\n" + FOOT)


TEMPLATES = {
    "first_approved": _approved("First", "You are now eligible for the Second Review."),
    "first_revision": _revision("First", "You remain at the First Review stage. The Second Review stays locked until this review is approved."),
    "second_approved": _approved("Second", "You are now eligible for the Third (final) Review."),
    "second_revision": _revision("Second", "You remain at the Second Review stage. The Third Review stays locked until this review is approved."),
    "third_approved": _approved("Third", "This was your final review. Your task is now marked Successfully Completed."),
    "third_revision": _revision("Third", "You remain at the Third Review stage and may resubmit until approval or the internship end date."),
    "reminder": ("[{company}] Reminder: {review_name} submission due {deadline} - {code}",
                 "Dear {name},\n\nThis is a friendly reminder that your submission for the {review_name} "
                 "is due on {deadline} ({days_left} day(s) remaining).\n\n" + INFO +
                 "\nNext steps:\n{next_steps}\n" + FOOT),
    "overdue": ("[{company}] Overdue: {review_name} submission - {code}",
                "Dear {name},\n\nYour submission for the {review_name} was due on {deadline} and is now "
                "{days_overdue} day(s) overdue. Nothing has been rejected - please submit as soon as you can, "
                "or contact your mentor if you need help or an extension.\n\n" + INFO +
                "\nNext steps:\n{next_steps}\n" + FOOT),
    "reviewer_pending": ("[{company}] Review pending: {name} ({code}) - {review_name}",
                         "Dear {mentor_name},\n\n{name} (ID: {code}) submitted work for the {review_name} "
                         "(attempt {attempt_no}) on {submitted_at}.\n\nTask: {task}\n"
                         "Student note: {submission_note}\n\nPlease evaluate it in the portal: {portal_url}\n\n"
                         "Regards,\n{hr_name}\nHuman Resources\n{company}\n{hr_email}\n"),
    "completion": ("[{company}] Internship completed - {code}",
                   "Dear {name},\n\nCongratulations! You have passed all three reviews and your internship task "
                   "is marked Successfully Completed.\n\n" + INFO +
                   "\nSummary of your progress:\n{progress}\n\nRemaining formalities:\n{formalities}\n" + FOOT),
}


class _Safe(dict):
    def __missing__(self, key):
        return "{" + key + "}"


def render(name, ctx):
    subject, body = TEMPLATES[name]
    return subject.format_map(_Safe(ctx)), body.format_map(_Safe(ctx))
