"""Create the database and 100 sample students (all e-mail addresses use the reserved .test domain).

  python seed.py                  empty progress, everyone at First Review
  python seed.py --demo-progress  also simulate realistic review activity (uses the real workflow code)
  python seed.py --reset          delete the existing database first
"""
import argparse, os, sys
from datetime import date, timedelta
import config, db, emailer, workflow

FIRST = ["Aarav", "Meena", "Karthik", "Priya", "Ravi", "Divya", "Arjun", "Lakshmi", "Suresh", "Anitha",
         "Vikram", "Nandhini", "Harish", "Kavya", "Manoj", "Sneha", "Dinesh", "Revathi", "Pranav", "Ishita"]
LAST = ["Kumar", "Raj", "Subramanian", "Iyer", "Nair", "Pillai", "Sharma", "Devi", "Murugan", "Selvam"]
TASKS = ["Customer onboarding dashboard", "HR policy chatbot", "Inventory tracking sheet", "Social media content calendar",
         "Payroll reconciliation tool", "Website accessibility audit", "Sales lead scoring model", "Employee survey analysis",
         "Mobile app UI redesign", "Data-cleaning pipeline", "Email campaign automation", "Meeting-notes summariser",
         "Invoice OCR prototype", "Customer feedback classifier", "Training-video editing package", "SEO audit report",
         "Task-management web app", "Recruitment tracker", "Knowledge-base articles", "Network-asset register"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--reset", action="store_true")
    ap.add_argument("--demo-progress", action="store_true")
    ap.add_argument("--start", help="internship start date YYYY-MM-DD (default: today, or 40 days ago with --demo-progress)")
    ap.add_argument("--password", default=os.environ.get("DEMO_PASSWORD", "Demo@12345"))
    a = ap.parse_args()
    if a.reset and os.path.exists(config.DB_PATH):
        os.remove(config.DB_PATH)
    conn = db.connect()
    db.init_db(conn)
    if conn.execute("SELECT COUNT(*) c FROM students").fetchone()["c"]:
        sys.exit("Database already has students. Use --reset to start over.")
    start = date.fromisoformat(a.start) if a.start else (date.today() - timedelta(days=40 if a.demo_progress else 0))
    with conn:
        for i in range(1, 6):
            conn.execute("INSERT INTO mentors(id,name,email) VALUES(?,?,?)", (i, "Mentor %d" % i, "mentor%d@example.test" % i))
            workflow.create_user(conn, "mentor%d" % i, a.password, "reviewer", mentor_id=i)
        workflow.create_user(conn, "hr.admin", a.password, "hr")
    for i in range(1, 101):
        name = "%s %s" % (FIRST[(i - 1) % 20], LAST[(i * 3) % 10])
        workflow.enroll_student(conn, "VMW-%03d" % i, name, "student%03d@example.test" % i, TASKS[(i - 1) % 20],
                                (i - 1) % 5 + 1, start, None, a.password)
    print("Created 5 mentors, 1 HR admin, 100 students (start date %s)." % start)
    if a.demo_progress:
        demo(conn)
    emailer.process_outbox(conn)
    print("Login: hr.admin / mentor1..mentor5 / VMW-001..VMW-100   password: %s  (DEMO ONLY - change before real use)" % a.password)
    print("Emails are %s." % ("SIMULATED (files in sent_emails/)" if config.EMAIL_MODE != "smtp" else "REAL (smtp mode)"))


def demo(conn):
    users = {u["mentor_id"]: u for u in conn.execute("SELECT * FROM users WHERE role='reviewer'")}
    students = conn.execute("SELECT * FROM students ORDER BY id").fetchall()
    t = date.today()

    def student_user(s):
        return conn.execute("SELECT * FROM users WHERE student_id=?", (s["id"],)).fetchone()

    def sub(s):
        return workflow.submit_work(conn, s["id"], "Work uploaded: https://example.test/work/%s" % s["student_code"], student_user(s))

    def dec(s, aid, d):
        rev = users[s["mentor_id"]]
        if d == "approved":
            workflow.decide(conn, aid, rev, d, "Meets the requirements for this stage.", "Clear structure; good documentation.")
        else:
            workflow.decide(conn, aid, rev, d, "Good start but incomplete.", "Solid basics.",
                            "Add error handling, tests and a README.", (t + timedelta(days=5)).isoformat())

    for i, s in enumerate(students[:70], start=1):
        k = i % 10
        if k in (0, 7, 8, 9):
            continue
        a1 = sub(s)
        if k == 1:
            continue                                  # pending first review
        if k == 3:
            dec(s, a1, "needs_revision"); continue    # first review needs revision
        dec(s, a1, "approved")
        if k == 2:
            continue                                  # approved first, waiting for second submission
        a2 = sub(s)
        if k == 4:
            continue                                  # pending second review
        if k == 5:
            dec(s, a2, "needs_revision"); continue    # second needs revision
        dec(s, a2, "approved")
        a3 = sub(s)
        if k == 6:
            dec(s, a3, "approved")                    # fully completed
    print("Demo progress created through the normal workflow (decisions + queued emails).")


if __name__ == "__main__":
    main()
