@echo off
cd /d "%~dp0"
where py >nul 2>nul && (set PY=py -3) || (set PY=python)
if not exist .env copy .env.example .env >nul
start "" http://127.0.0.1:8000
%PY% app.py
pause
