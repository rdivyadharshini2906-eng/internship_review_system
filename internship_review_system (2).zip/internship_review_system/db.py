"""SQLite schema, connection, settings, simulated 'today' and audit helpers."""
import os, sqlite3
from datetime import date, datetime
import config

SCHEMA = r"""
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS mentors(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE);
CREATE TABLE IF NOT EXISTS students(
  id INTEGER PRIMARY KEY, student_code TEXT NOT NULL UNIQUE, name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE, task_title TEXT NOT NULL, task_description TEXT DEFAULT '',
  mentor_id INTEGER NOT NULL REFERENCES mentors(id),
  start_date TEXT NOT NULL, end_date TEXT NOT NULL,
  current_stage INTEGER NOT NULL DEFAULT 1 CHECK(current_stage BETWEEN 1 AND 3),
  deadline TEXT NOT NULL, completed INTEGER NOT NULL DEFAULT 0, completed_at TEXT,
  active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL,
  salt TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('hr','reviewer','student')),
  student_id INTEGER REFERENCES students(id), mentor_id INTEGER REFERENCES mentors(id));
CREATE TABLE IF NOT EXISTS attempts(
  id INTEGER PRIMARY KEY, uid TEXT NOT NULL UNIQUE,
  student_id INTEGER NOT NULL REFERENCES students(id),
  stage INTEGER NOT NULL CHECK(stage BETWEEN 1 AND 3), attempt_no INTEGER NOT NULL,
  submitted_at TEXT NOT NULL, submission_note TEXT DEFAULT '',
  state TEXT NOT NULL DEFAULT 'submitted' CHECK(state IN ('submitted','approved','needs_revision')),
  reviewer_user_id INTEGER REFERENCES users(id), decided_at TEXT,
  feedback TEXT, strengths TEXT, corrections TEXT, resubmit_deadline TEXT,
  UNIQUE(student_id, stage, attempt_no));
CREATE TABLE IF NOT EXISTS email_outbox(
  id INTEGER PRIMARY KEY, dedupe_key TEXT NOT NULL UNIQUE,
  student_id INTEGER REFERENCES students(id), to_addr TEXT NOT NULL, cc_addr TEXT,
  template TEXT NOT NULL, subject TEXT NOT NULL, body TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending'
    CHECK(status IN ('pending','sending','sent','simulated','failed','failed_permanent')),
  attempts INTEGER NOT NULL DEFAULT 0, next_retry_at TEXT, claimed_at TEXT,
  last_error TEXT, created_at TEXT NOT NULL, sent_at TEXT);
CREATE TABLE IF NOT EXISTS email_log(
  id INTEGER PRIMARY KEY, outbox_id INTEGER NOT NULL REFERENCES email_outbox(id),
  ts TEXT NOT NULL, result TEXT NOT NULL, error TEXT);
CREATE TABLE IF NOT EXISTS audit_log(
  id INTEGER PRIMARY KEY, ts TEXT NOT NULL, actor TEXT NOT NULL, action TEXT NOT NULL, detail TEXT);

-- Business rules enforced inside the database as a second line of defence --
CREATE TRIGGER IF NOT EXISTS trg_attempt_insert_lock BEFORE INSERT ON attempts
WHEN NEW.stage > 1 AND NOT EXISTS (SELECT 1 FROM attempts WHERE student_id=NEW.student_id
     AND stage=NEW.stage-1 AND state='approved')
BEGIN SELECT RAISE(ABORT,'Review locked: the previous review is not approved'); END;

CREATE TRIGGER IF NOT EXISTS trg_attempt_one_open BEFORE INSERT ON attempts
WHEN EXISTS (SELECT 1 FROM attempts WHERE student_id=NEW.student_id AND stage=NEW.stage
     AND state IN ('submitted','approved'))
BEGIN SELECT RAISE(ABORT,'This review already has a pending or approved attempt'); END;

CREATE TRIGGER IF NOT EXISTS trg_attempt_approve_lock BEFORE UPDATE OF state ON attempts
WHEN NEW.state='approved' AND NEW.stage > 1 AND NOT EXISTS (SELECT 1 FROM attempts
     WHERE student_id=NEW.student_id AND stage=NEW.stage-1 AND state='approved')
BEGIN SELECT RAISE(ABORT,'Cannot approve: the previous review is not approved'); END;

CREATE TRIGGER IF NOT EXISTS trg_attempt_immutable BEFORE UPDATE ON attempts
WHEN OLD.state <> 'submitted'
BEGIN SELECT RAISE(ABORT,'Decided review attempts are immutable'); END;

CREATE TRIGGER IF NOT EXISTS trg_attempt_nodelete BEFORE DELETE ON attempts
BEGIN SELECT RAISE(ABORT,'Review attempts cannot be deleted'); END;
"""


def connect(path=None):
    path = path or config.DB_PATH
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    conn = sqlite3.connect(path, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db(conn):
    conn.executescript(SCHEMA)
    for k, v in config.DEFAULT_SETTINGS.items():
        conn.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k, v))
    conn.commit()


def now_iso():
    return datetime.now().isoformat(sep=" ", timespec="seconds")


def get_setting(conn, key, default=None):
    r = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    if r:
        return r["value"]
    return config.DEFAULT_SETTINGS.get(key, default)


def get_int(conn, key):
    return int(get_setting(conn, key))


def set_setting(conn, key, value):
    conn.execute("INSERT INTO settings(key,value) VALUES(?,?) "
                 "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))


def today(conn):
    """Real date, unless a test-mode 'simulated today' has been set."""
    sim = conn.execute("SELECT value FROM settings WHERE key='sim_today'").fetchone()
    if sim and sim["value"]:
        return date.fromisoformat(sim["value"])
    return date.today()


def audit(conn, actor, action, detail=""):
    conn.execute("INSERT INTO audit_log(ts,actor,action,detail) VALUES(?,?,?,?)",
                 (now_iso(), actor, action, detail))
