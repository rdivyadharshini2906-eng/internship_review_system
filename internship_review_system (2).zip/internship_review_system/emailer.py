"""Email queue (outbox). Approval and sending are separate: decisions are saved first,
emails are queued with a unique dedupe key and delivered/retried independently."""
import os, smtplib
from datetime import date, datetime, timedelta
from email.message import EmailMessage
import config, db
from email_templates import render

STAGE_NAMES = {1: "First Review", 2: "Second Review", 3: "Third Review"}
WORD = {1: "first", 2: "second", 3: "third"}


def fmt_date(v):
    return date.fromisoformat(v).strftime("%d %b %Y") if v else "-"


def build_context(conn, student_id, attempt=None, stage=None, extra=None):
    s = conn.execute("SELECT s.*, m.name mentor_name, m.email mentor_email FROM students s "
                     "JOIN mentors m ON m.id=s.mentor_id WHERE s.id=?", (student_id,)).fetchone()
    t = db.today(conn)
    start, end = date.fromisoformat(s["start_date"]), date.fromisoformat(s["end_date"])
    total = (end - start).days + 1
    stage = attempt["stage"] if attempt else (stage or s["current_stage"])
    if attempt:
        attempt_no = attempt["attempt_no"]
    else:
        attempt_no = conn.execute("SELECT COUNT(*) c FROM attempts WHERE student_id=? AND stage=?",
                                  (student_id, stage)).fetchone()["c"] + 1
    deadline = date.fromisoformat(s["deadline"])
    ctx = dict(
        company=config.COMPANY_NAME, name=s["name"], code=s["student_code"], task=s["task_title"],
        review_name=STAGE_NAMES[stage], attempt_no=attempt_no,
        outcome={"approved": "APPROVED", "needs_revision": "NEEDS REVISION"}.get(
            attempt["state"] if attempt else "", "Pending"),
        day=max(1, min(total, (t - start).days + 1)), total_days=total,
        mentor_name=s["mentor_name"], mentor_email=s["mentor_email"],
        hr_name=config.HR_NAME, hr_email=config.HR_EMAIL, portal_url=config.PORTAL_URL,
        deadline=fmt_date(s["deadline"]), days_left=max(0, (deadline - t).days),
        days_overdue=max(0, (t - deadline).days),
        comments=(attempt["feedback"] if attempt and attempt["feedback"] else "-"),
        strengths_block="", corrections_block="", next_steps="",
        submitted_at=attempt["submitted_at"] if attempt else "",
        submission_note=(attempt["submission_note"] or "-") if attempt else "-",
        formalities=db.get_setting(conn, "completion_formalities"), progress="",
    )
    if attempt and attempt["strengths"]:
        ctx["strengths_block"] = "What you completed well:\n%s\n\n" % attempt["strengths"]
    if attempt and attempt["corrections"]:
        ctx["corrections_block"] = "Required corrections and improvements:\n%s\n\n" % attempt["corrections"]
    ctx.update(extra or {})
    return s, ctx


def queue(conn, template, student_id, key, attempt=None, stage=None, to=None, cc=None, extra=None):
    """Insert an email into the outbox. Returns True if new, False if the key already existed."""
    s, ctx = build_context(conn, student_id, attempt, stage, extra)
    subject, body = render(template, ctx)
    cur = conn.execute(
        "INSERT OR IGNORE INTO email_outbox(dedupe_key,student_id,to_addr,cc_addr,template,subject,body,"
        "status,created_at) VALUES(?,?,?,?,?,?,?,'pending',?)",
        (key, student_id, to or s["email"], cc, template, subject, body, db.now_iso()))
    return cur.rowcount == 1


def queue_outcome(conn, attempt_id):
    a = conn.execute("SELECT * FROM attempts WHERE id=?", (attempt_id,)).fetchone()
    sid, stage = a["student_id"], a["stage"]
    s = conn.execute("SELECT * FROM students WHERE id=?", (sid,)).fetchone()
    portal = config.PORTAL_URL
    if a["state"] == "approved":
        tpl = WORD[stage] + "_approved"
        steps = {1: "Continue with your assigned task and prepare it for the Second Review.",
                 2: "Continue and prepare your task for the Third (final) Review.",
                 3: "No further review is needed. See the completion email for remaining formalities."}[stage]
        steps += "\nSubmit through the portal: " + portal if stage < 3 else ""
    else:
        tpl = WORD[stage] + "_revision"
        steps = ("1. Fix the corrections listed above.\n2. Log in to the portal: " + portal +
                 "\n3. Open your profile and use 'Submit work' before the resubmission deadline.")
    queue(conn, tpl, sid, "attempt:%s:outcome" % a["uid"], attempt=a, extra={"next_steps": steps})
    if a["state"] == "approved" and stage == 3:
        approved = conn.execute("SELECT stage, decided_at FROM attempts WHERE student_id=? AND state='approved' "
                                "ORDER BY stage", (sid,)).fetchall()
        prog = "\n".join("- %s approved on %s" % (STAGE_NAMES[r["stage"]], r["decided_at"][:10]) for r in approved)
        queue(conn, "completion", sid, "student:%s:completion" % sid, attempt=a, extra={"progress": prog})


# ---------------------------------------------------------------- delivery
def simulated_sender(row):
    if config.env("EMAIL_SIMULATE_FAIL") == "1":
        raise RuntimeError("Simulated email-service outage (EMAIL_SIMULATE_FAIL=1)")
    os.makedirs(config.SIM_DIR, exist_ok=True)
    fn = os.path.join(config.SIM_DIR, "%05d_%s.txt" % (row["id"], row["template"]))
    with open(fn, "w", encoding="utf-8") as f:
        f.write("To: %s\nCc: %s\nSubject: %s\n\n%s" % (row["to_addr"], row["cc_addr"] or "", row["subject"], row["body"]))
    return "simulated"


def smtp_sender(row):
    if not (config.SMTP_HOST and config.SMTP_FROM):
        raise RuntimeError("SMTP_HOST / SMTP_FROM not configured")
    msg = EmailMessage()
    msg["From"], msg["To"], msg["Subject"] = config.SMTP_FROM, row["to_addr"], row["subject"]
    if row["cc_addr"]:
        msg["Cc"] = row["cc_addr"]
    msg.set_content(row["body"])
    with smtplib.SMTP(config.SMTP_HOST, config.SMTP_PORT, timeout=30) as smtp:
        smtp.starttls()
        if config.SMTP_USER:
            smtp.login(config.SMTP_USER, config.SMTP_PASSWORD)
        smtp.send_message(msg)
    return "sent"


def default_sender():
    return smtp_sender if config.EMAIL_MODE == "smtp" else simulated_sender


def process_outbox(conn, sender=None, now=None, limit=500):
    """Deliver due emails. Each email is claimed atomically so it cannot be sent twice concurrently.
    Failures are logged and retried with exponential backoff (15, 30, 60... minutes)."""
    sender = sender or default_sender()
    now = now or datetime.now()
    now_s = now.isoformat(sep=" ", timespec="seconds")
    stale = (now - timedelta(minutes=10)).isoformat(sep=" ", timespec="seconds")
    max_attempts = db.get_int(conn, "email_max_attempts")
    rows = conn.execute(
        "SELECT id FROM email_outbox WHERE (status IN ('pending','failed') AND (next_retry_at IS NULL OR next_retry_at<=?)) "
        "OR (status='sending' AND claimed_at<=?) ORDER BY id LIMIT ?", (now_s, stale, limit)).fetchall()
    result = {"sent": 0, "failed": 0}
    for r in rows:
        cur = conn.execute("UPDATE email_outbox SET status='sending', claimed_at=? WHERE id=? AND "
                           "(status IN ('pending','failed') OR (status='sending' AND claimed_at<=?))",
                           (now_s, r["id"], stale))
        conn.commit()
        if cur.rowcount != 1:
            continue
        row = conn.execute("SELECT * FROM email_outbox WHERE id=?", (r["id"],)).fetchone()
        try:
            status = sender(row)
            conn.execute("UPDATE email_outbox SET status=?, attempts=attempts+1, sent_at=?, last_error=NULL WHERE id=?",
                         (status, now_s, row["id"]))
            conn.execute("INSERT INTO email_log(outbox_id,ts,result) VALUES(?,?,?)", (row["id"], now_s, status))
            result["sent"] += 1
        except Exception as e:  # any delivery problem is logged, never lost
            n = row["attempts"] + 1
            if n >= max_attempts:
                st, nxt = "failed_permanent", None
            else:
                st, nxt = "failed", (now + timedelta(minutes=15 * 2 ** (n - 1))).isoformat(sep=" ", timespec="seconds")
            conn.execute("UPDATE email_outbox SET status=?, attempts=?, next_retry_at=?, last_error=? WHERE id=?",
                         (st, n, nxt, str(e)[:300], row["id"]))
            conn.execute("INSERT INTO email_log(outbox_id,ts,result,error) VALUES(?,?,?,?)",
                         (row["id"], now_s, st, str(e)[:300]))
            result["failed"] += 1
        conn.commit()
    return result
