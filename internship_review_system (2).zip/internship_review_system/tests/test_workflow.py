"""Scenario tests A-J from the specification. Run:  python -m unittest discover -v
Uses a temporary database and simulated email only - nothing is ever sent."""
import os, sqlite3, sys, tempfile, unittest
from datetime import date, datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config, db, emailer, reports, scheduler, workflow
from workflow import PermissionDenied, WorkflowError

START = date(2026, 1, 5)
D = lambda n: (START + timedelta(days=n)).isoformat()


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        config.SIM_DIR = os.path.join(self.tmp.name, "sent")
        os.environ.pop("EMAIL_SIMULATE_FAIL", None)
        self.conn = db.connect(os.path.join(self.tmp.name, "t.db"))
        db.init_db(self.conn)
        self.conn.execute("INSERT INTO mentors(id,name,email) VALUES(1,'Mentor One','m1@example.test'),(2,'Mentor Two','m2@example.test')")
        self.conn.commit()
        for u, r, m in (("m1", "reviewer", 1), ("m2", "reviewer", 2), ("hr", "hr", None)):
            workflow.create_user(self.conn, u, "password1", r, mentor_id=m)
        self.conn.commit()
        self.today(0)

    def tearDown(self):
        self.conn.close()
        self.tmp.cleanup()

    def today(self, n):
        db.set_setting(self.conn, "sim_today", D(n))
        self.conn.commit()

    def user(self, name):
        return self.conn.execute("SELECT * FROM users WHERE username=?", (name,)).fetchone()

    def student(self, code, mentor=1):
        return workflow.enroll_student(self.conn, code, "Student " + code, code.lower() + "@example.test", "Task " + code,
                                       mentor, START, self.user("hr"), "password1")

    def sub(self, sid):
        name = self.conn.execute("SELECT username FROM users WHERE student_id=?", (sid,)).fetchone()["username"]
        return workflow.submit_work(self.conn, sid, "my work", self.user(name))

    def approve(self, aid, mentor="m1"):
        workflow.decide(self.conn, aid, self.user(mentor), "approved", "Good work", "Nice structure")

    def reject(self, aid, mentor="m1"):
        workflow.decide(self.conn, aid, self.user(mentor), "needs_revision", "Incomplete", "Basics ok", "Add tests", D(20))

    def stu(self, sid):
        return self.conn.execute("SELECT * FROM students WHERE id=?", (sid,)).fetchone()

    def emails(self, sid, template=None):
        q, a = "SELECT * FROM email_outbox WHERE student_id=?", [sid]
        if template:
            q, a = q + " AND template=?", a + [template]
        return self.conn.execute(q, a).fetchall()


class TestScenarios(Base):
    def test_A_pass_review1_unlocks_review2(self):
        a = self.student("A")
        aid = self.sub(a)
        self.approve(aid)
        emailer.process_outbox(self.conn)
        self.assertEqual(self.stu(a)["current_stage"], 2)
        em = self.emails(a, "first_approved")
        self.assertEqual(len(em), 1)
        self.assertEqual(em[0]["status"], "simulated")
        self.assertIn("eligible for the Second Review", em[0]["body"])
        self.assertIn("Day 1 of 100", em[0]["body"])
        self.assertIn("Good work", em[0]["body"])
        self.assertTrue(os.path.exists(config.SIM_DIR))
        self.sub(a)  # review 2 attempt is now allowed

    def test_B_fail_review1_keeps_review2_locked_and_allows_resubmission(self):
        b = self.student("B")
        a1 = self.sub(b)
        self.reject(a1)
        self.assertEqual(self.stu(b)["current_stage"], 1)
        self.assertEqual(self.stu(b)["deadline"], D(20))
        body = self.emails(b, "first_revision")[0]["body"]
        self.assertIn("Add tests", body)
        self.assertIn("Resubmission deadline", body)
        with self.assertRaises(sqlite3.DatabaseError):  # DB-level lock, bypassing the app
            self.conn.execute("INSERT INTO attempts(uid,student_id,stage,attempt_no,submitted_at) VALUES('x',?,2,1,'now')", (b,))
        self.conn.rollback()
        a2 = self.sub(b)
        n = self.conn.execute("SELECT attempt_no, stage FROM attempts WHERE id=?", (a2,)).fetchone()
        self.assertEqual((n["attempt_no"], n["stage"]), (2, 1))
        old = self.conn.execute("SELECT state, feedback FROM attempts WHERE id=?", (a1,)).fetchone()
        self.assertEqual((old["state"], old["feedback"]), ("needs_revision", "Incomplete"))  # history preserved

    def test_C_pass1_fail2_stays_at_review2(self):
        c = self.student("C")
        self.approve(self.sub(c))
        self.reject(self.sub(c))
        s = self.stu(c)
        self.assertEqual((s["current_stage"], s["completed"]), (2, 0))
        self.assertEqual(len(self.emails(c, "second_revision")), 1)
        with self.assertRaises(sqlite3.DatabaseError):
            self.conn.execute("INSERT INTO attempts(uid,student_id,stage,attempt_no,submitted_at) VALUES('y',?,3,1,'now')", (c,))
        self.conn.rollback()

    def test_D_pass_all_three_completes_and_sends_final_email(self):
        d = self.student("D")
        for _ in range(3):
            self.approve(self.sub(d))
        self.assertEqual(self.stu(d)["completed"], 1)
        names = sorted(e["template"] for e in self.emails(d))
        self.assertEqual(names, sorted(["first_approved", "second_approved", "third_approved", "completion"] + ["reviewer_pending"] * 3))
        self.assertIn("Successfully Completed", self.emails(d, "completion")[0]["body"])
        self.assertEqual([r for r in reports.snapshot(self.conn) if r["id"] == d][0]["state"], "completed")

    def test_E_missed_deadline_is_flagged_not_rejected(self):
        e = self.student("E")
        self.today(35)  # stage-1 deadline is day 30
        r = scheduler.run_cycle(self.conn)
        self.assertEqual(r["queued"]["overdue"], 1)
        row = [x for x in reports.snapshot(self.conn) if x["id"] == e][0]
        self.assertTrue(row["overdue"])
        self.assertEqual((row["state"], row["current_stage"]), ("awaiting_submission", 1))
        self.assertEqual(self.conn.execute("SELECT COUNT(*) c FROM attempts").fetchone()["c"], 0)  # nothing rejected
        em = self.emails(e, "overdue")[0]
        self.assertEqual(em["cc_addr"], "m1@example.test")
        self.assertIn("Nothing has been rejected", em["body"])
        scheduler.run_cycle(self.conn)  # same day again: no duplicate
        self.assertEqual(len(self.emails(e, "overdue")), 1)
        self.today(36)
        scheduler.run_cycle(self.conn)
        self.assertEqual(len(self.emails(e, "overdue")), 1)  # repeat interval (3 days) not reached
        self.today(38)
        scheduler.run_cycle(self.conn)
        self.assertEqual(len(self.emails(e, "overdue")), 2)

    def test_F_email_outage_keeps_decision_and_retries_safely(self):
        f = self.student("F")
        aid = self.sub(f)
        self.approve(aid)

        def boom(row):
            raise RuntimeError("SMTP down")
        t0 = datetime(2026, 1, 5, 10, 0, 0)
        emailer.process_outbox(self.conn, sender=boom, now=t0)
        self.assertEqual(self.conn.execute("SELECT state FROM attempts WHERE id=?", (aid,)).fetchone()["state"], "approved")
        em = self.emails(f, "first_approved")[0]
        self.assertEqual((em["status"], em["attempts"]), ("failed", 1))
        self.assertIn("SMTP down", em["last_error"])
        self.assertIsNotNone(em["next_retry_at"])
        self.assertEqual(self.conn.execute("SELECT COUNT(*) c FROM email_log WHERE outbox_id=? AND result='failed'", (em["id"],)).fetchone()["c"], 1)
        sent = []
        ok = lambda row: sent.append(row["id"]) or "simulated"
        emailer.process_outbox(self.conn, sender=ok, now=t0 + timedelta(minutes=5))  # too early
        self.assertNotIn(em["id"], sent)
        emailer.process_outbox(self.conn, sender=ok, now=t0 + timedelta(minutes=16))
        emailer.process_outbox(self.conn, sender=ok, now=t0 + timedelta(hours=3))  # nothing left to resend
        self.assertEqual(sent.count(em["id"]), 1)
        self.assertEqual(self.emails(f, "first_approved")[0]["status"], "simulated")

    def test_G_students_are_independent(self):
        x, y = self.student("X"), self.student("Y")
        self.sub(x)  # X waits for review
        for _ in range(3):
            self.approve(self.sub(y))
        rows = {r["id"]: r for r in reports.snapshot(self.conn)}
        self.assertEqual(rows[x]["state"], "awaiting_review")
        self.assertEqual(rows[y]["state"], "completed")
        self.assertEqual(self.stu(x)["current_stage"], 1)

    def test_H_day100_with_pending_review_is_not_success(self):
        h = self.student("H")
        aid = self.sub(h)
        self.assertEqual(date.fromisoformat(self.stu(h)["end_date"]), START + timedelta(days=99))
        self.today(100)  # day 101
        row = [x for x in reports.snapshot(self.conn) if x["id"] == h][0]
        self.assertEqual(row["state"], "ended_pending")
        self.assertEqual(reports.final_report([row])[0]["Final outcome"], "Internship ended with pending reviews")
        with self.assertRaises(WorkflowError):
            self.approve(aid)
        self.assertEqual(self.stu(h)["completed"], 0)
        before = self.conn.execute("SELECT COUNT(*) c FROM email_outbox").fetchone()["c"]
        scheduler.run_cycle(self.conn)
        self.assertEqual(self.conn.execute("SELECT COUNT(*) c FROM email_outbox").fetchone()["c"], before)  # reminders stopped

    def test_I_duplicate_event_creates_no_duplicates(self):
        i = self.student("I")
        aid = self.sub(i)
        self.approve(aid)
        self.approve(aid)  # same event processed twice
        self.assertEqual(self.conn.execute("SELECT COUNT(*) c FROM attempts WHERE student_id=?", (i,)).fetchone()["c"], 1)
        self.assertEqual(len(self.emails(i, "first_approved")), 1)
        self.assertEqual(self.stu(i)["current_stage"], 2)  # not advanced twice
        with self.assertRaises(WorkflowError):
            self.reject(aid)  # a different decision on a decided attempt is refused
        self.sub(i)
        with self.assertRaises(WorkflowError):
            self.sub(i)  # second submit while one is pending
        uid = self.conn.execute("SELECT uid FROM attempts WHERE id=?", (aid,)).fetchone()["uid"]
        self.assertFalse(emailer.queue(self.conn, "reminder", i, "attempt:%s:outcome" % uid, extra={"next_steps": ""}))

    def test_J_unauthorised_approval_is_rejected(self):
        j = self.student("J")
        aid = self.sub(j)
        for who in ("J", "m2", "hr"):  # student himself, another mentor, HR
            with self.assertRaises(PermissionDenied):
                workflow.decide(self.conn, aid, self.user(who), "approved", "I approve myself")
        self.assertEqual(self.conn.execute("SELECT state FROM attempts WHERE id=?", (aid,)).fetchone()["state"], "submitted")
        self.assertEqual(self.stu(j)["current_stage"], 1)
        self.assertEqual(self.conn.execute("SELECT COUNT(*) c FROM audit_log WHERE action='DENIED_DECISION'").fetchone()["c"], 3)
        self.approve(aid)
        with self.assertRaises(sqlite3.DatabaseError):  # DB trigger: decided attempts are immutable
            self.conn.execute("UPDATE attempts SET state='needs_revision' WHERE id=?", (aid,))
        self.conn.rollback()
        with self.assertRaises(sqlite3.DatabaseError):
            self.conn.execute("DELETE FROM attempts")
        self.conn.rollback()


class TestExtras(Base):
    def test_revision_requires_corrections_and_valid_deadline(self):
        s = self.student("K")
        aid = self.sub(s)
        with self.assertRaises(WorkflowError):
            workflow.decide(self.conn, aid, self.user("m1"), "needs_revision", "bad", "", "", D(10))
        with self.assertRaises(WorkflowError):
            workflow.decide(self.conn, aid, self.user("m1"), "needs_revision", "bad", "", "fix", "2030-01-01")
        self.assertEqual(self.conn.execute("SELECT state FROM attempts WHERE id=?", (aid,)).fetchone()["state"], "submitted")

    def test_reminder_before_deadline_and_extension_audited(self):
        s = self.student("L")
        self.today(29)
        scheduler.run_cycle(self.conn)
        self.assertEqual(len(self.emails(s, "reminder")), 1)
        with self.assertRaises(WorkflowError):
            workflow.hr_extend(self.conn, s, "deadline", D(40), "", self.user("hr"))  # reason required
        workflow.hr_extend(self.conn, s, "deadline", D(40), "Medical leave", self.user("hr"))
        self.assertEqual(self.stu(s)["deadline"], D(40))
        self.assertEqual(self.conn.execute("SELECT COUNT(*) c FROM audit_log WHERE action='EXTEND_DEADLINE'").fetchone()["c"], 1)
        with self.assertRaises(PermissionDenied):
            workflow.hr_extend(self.conn, s, "deadline", D(41), "x", self.user("m1"))

    def test_student_cannot_submit_for_someone_else(self):
        a, b = self.student("M"), self.student("N")
        with self.assertRaises(PermissionDenied):
            workflow.submit_work(self.conn, a, "x", self.user("N"))

    def test_csv_export_neutralises_formulas(self):
        out = reports.to_csv([{"a": "=1+1", "b": "ok"}], ["a", "b"]).decode("utf-8-sig")
        self.assertIn("'=1+1", out)


if __name__ == "__main__":
    unittest.main(verbosity=2)
